/**
 * ═══════════════════════════════════════════════════════════════
 * Auth Module — Login & Registration Logic
 * ═══════════════════════════════════════════════════════════════
 */

document.addEventListener('DOMContentLoaded', () => {
    // Check if already logged in
    const auth = getAuth();
    if (auth && auth.token) {
        redirectByRole(auth.user.role);
        return;
    }

    initAuthPage();
});

function initAuthPage() {
    const roleToggleBtns = document.querySelectorAll('.role-toggle-btn');
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const showRegisterLink = document.getElementById('show-register');
    const showLoginLink = document.getElementById('show-login');
    const loginSection = document.getElementById('login-section');
    const registerSection = document.getElementById('register-section');

    let currentRole = 'patient';

    // Role toggle
    roleToggleBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            roleToggleBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            currentRole = btn.dataset.role;

            // Show/hide doctor-specific fields
            const doctorFields = document.querySelectorAll('.doctor-only');
            const patientFields = document.querySelectorAll('.patient-only');
            doctorFields.forEach(f => f.style.display = currentRole === 'doctor' ? 'block' : 'none');
            patientFields.forEach(f => f.style.display = currentRole === 'patient' ? 'block' : 'none');
        });
    });

    // Toggle login/register views
    if (showRegisterLink) {
        showRegisterLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.classList.add('hidden');
            registerSection.classList.remove('hidden');
        });
    }

    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            registerSection.classList.add('hidden');
            loginSection.classList.remove('hidden');
        });
    }

    // Login form
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitBtn = loginForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner"></span> Authenticating...';

            const email = document.getElementById('login-email').value.trim();
            const password = document.getElementById('login-password').value;

            try {
                const result = await apiCall('/auth/login', 'POST', { email, password });
                if (result && result.success) {
                    saveAuth(result.token, result.user);
                    showToast(`Welcome back, ${result.user.name}!`, 'success');
                    setTimeout(() => redirectByRole(result.user.role), 800);
                } else if (result) {
                    showToast(result.error || 'Login failed', 'error');
                } else {
                    // Backend unavailable — use demo login
                    handleOfflineLogin(email, password);
                }
            } catch (err) {
                showToast(err.message, 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        });
    }

    // Register form
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const submitBtn = registerForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;

            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner"></span> Creating Account...';

            const name = document.getElementById('reg-name').value.trim();
            const email = document.getElementById('reg-email').value.trim();
            const password = document.getElementById('reg-password').value;
            const confirmPassword = document.getElementById('reg-confirm-password').value;

            if (password !== confirmPassword) {
                showToast('Passwords do not match', 'error');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }

            if (password.length < 6) {
                showToast('Password must be at least 6 characters', 'error');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                return;
            }

            const body = { name, email, password, role: currentRole };

            if (currentRole === 'doctor') {
                body.specialization = document.getElementById('reg-specialization')?.value || 'General Medicine';
                body.experience_years = parseInt(document.getElementById('reg-experience')?.value || '0');
            } else {
                body.age = parseInt(document.getElementById('reg-age')?.value || '0');
                body.gender = document.getElementById('reg-gender')?.value || '';
                body.blood_group = document.getElementById('reg-blood-group')?.value || '';
            }

            try {
                const result = await apiCall('/auth/register', 'POST', body);
                if (result && result.success) {
                    saveAuth(result.token, result.user);
                    showToast('Account created successfully!', 'success');
                    setTimeout(() => redirectByRole(result.user.role), 800);
                } else if (result) {
                    showToast(result.error || 'Registration failed', 'error');
                } else {
                    handleOfflineRegister(body);
                }
            } catch (err) {
                showToast(err.message, 'error');
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        });
    }
}

function redirectByRole(role) {
    if (role === 'doctor') {
        window.location.href = '/doctor';
    } else {
        window.location.href = '/patient';
    }
}

// ── Offline/LocalStorage Login Fallback ──
function handleOfflineLogin(email, password) {
    // Demo credentials
    const demoCreds = {
        'rahul@patient.com': { name: 'Rahul Verma', role: 'patient', role_id: 1 },
        'dr.sharma@hospital.com': { name: 'Dr. Arun Sharma', role: 'doctor', role_id: 1 },
        'dr.patel@hospital.com': { name: 'Dr. Priya Patel', role: 'doctor', role_id: 2 },
    };

    const user = demoCreds[email];
    if (user && password === 'demo123') {
        const fakeToken = btoa(JSON.stringify({ user_id: Math.random(), ...user, exp: Date.now() + 86400000 }));
        saveAuth(fakeToken, { id: Math.floor(Math.random() * 100), email, ...user });
        showToast(`Welcome, ${user.name}! (Offline Mode)`, 'success');
        setTimeout(() => redirectByRole(user.role), 800);
    } else {
        showToast('Invalid credentials. Try demo123 password.', 'error');
    }
}

function handleOfflineRegister(body) {
    const fakeUser = {
        id: Date.now(),
        name: body.name,
        email: body.email,
        role: body.role,
        role_id: Date.now()
    };
    const fakeToken = btoa(JSON.stringify({ user_id: fakeUser.id, ...fakeUser, exp: Date.now() + 86400000 }));
    saveAuth(fakeToken, fakeUser);
    showToast('Account created! (Offline Mode)', 'success');
    setTimeout(() => redirectByRole(body.role), 800);
}
