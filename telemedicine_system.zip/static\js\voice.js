/**
 * ═══════════════════════════════════════════════════════════════
 * Voice Module — Speech Recognition, Translation, Text-to-Speech
 * Supports: Hindi, Kannada, Telugu, Tamil, Malayalam, Marathi,
 *           Gujarati, Tulu, Bhojpuri, Spanish, English
 * ═══════════════════════════════════════════════════════════════
 */

const LANGUAGES = {
    'en': { name: 'English', code: 'en-US', flag: '🇬🇧' },
    'hi': { name: 'Hindi', code: 'hi-IN', flag: '🇮🇳' },
    'kn': { name: 'Kannada', code: 'kn-IN', flag: '🇮🇳' },
    'te': { name: 'Telugu', code: 'te-IN', flag: '🇮🇳' },
    'ta': { name: 'Tamil', code: 'ta-IN', flag: '🇮🇳' },
    'ml': { name: 'Malayalam', code: 'ml-IN', flag: '🇮🇳' },
    'mr': { name: 'Marathi', code: 'mr-IN', flag: '🇮🇳' },
    'gu': { name: 'Gujarati', code: 'gu-IN', flag: '🇮🇳' },
    'tulu': { name: 'Tulu', code: 'kn-IN', flag: '🇮🇳' },       // Uses Kannada ASR
    'bho': { name: 'Bhojpuri', code: 'hi-IN', flag: '🇮🇳' },     // Uses Hindi ASR
    'es': { name: 'Spanish', code: 'es-ES', flag: '🇪🇸' }
};

// ── Medical Translation Dictionaries ──
const MEDICAL_DICT = {
    'hi': {
        'सिरदर्द': 'headache', 'बुखार': 'fever', 'खांसी': 'cough',
        'जुकाम': 'cold', 'उल्टी': 'vomiting', 'दस्त': 'diarrhea',
        'पेट दर्द': 'stomach pain', 'छाती में दर्द': 'chest pain',
        'सांस लेने में तकलीफ': 'difficulty breathing', 'चक्कर': 'dizziness',
        'कमजोरी': 'weakness', 'थकान': 'fatigue', 'जलन': 'burning sensation',
        'खुजली': 'itching', 'सूजन': 'swelling', 'दर्द': 'pain',
        'बदन दर्द': 'body ache', 'गले में खराश': 'sore throat',
        'नाक बहना': 'runny nose', 'पेशाब में जलन': 'burning urination',
        'भूख नहीं': 'loss of appetite', 'नींद नहीं आती': 'insomnia',
        'जी मिचलाना': 'nausea', 'कब्ज': 'constipation',
        'दवाई': 'medicine', 'डॉक्टर': 'doctor', 'अस्पताल': 'hospital',
        'ब्लड प्रेशर': 'blood pressure', 'शुगर': 'diabetes',
        'एलर्जी': 'allergy', 'चोट': 'injury', 'बहुत दर्द': 'severe pain',
        'दिल': 'heart', 'सर': 'head', 'पेट': 'stomach', 'आँख': 'eye',
        'कान': 'ear', 'गला': 'throat', 'हड्डी': 'bone', 'खून': 'blood',
    },
    'kn': {
        'ತಲೆನೋವು': 'headache', 'ಜ್ವರ': 'fever', 'ಕೆಮ್ಮು': 'cough',
        'ನೆಗಡಿ': 'cold', 'ವಾಂತಿ': 'vomiting', 'ಭೇದಿ': 'diarrhea',
        'ಹೊಟ್ಟೆ ನೋವು': 'stomach pain', '�ದೆ ನೋವು': 'chest pain',
        'ಉಸಿರಾಟದ ತೊಂದರೆ': 'difficulty breathing', 'ತಲೆ ತಿರುಗುವಿಕೆ': 'dizziness',
        'ದೌರ್ಬಲ್ಯ': 'weakness', 'ಆಯಾಸ': 'fatigue',
        'ತುರಿಕೆ': 'itching', 'ಊತ': 'swelling', 'ನೋವು': 'pain',
        'ಮೈ ನೋವು': 'body ache', 'ಗಂಟಲು ನೋವು': 'sore throat',
    },
    'te': {
        'తలనొప్పి': 'headache', 'జ్వరం': 'fever', 'దగ్గు': 'cough',
        'జలుబు': 'cold', 'వాంతులు': 'vomiting', 'విరేచనాలు': 'diarrhea',
        'కడుపు నొప్పి': 'stomach pain', 'ఛాతీ నొప్పి': 'chest pain',
        'ఊపిరి ఆడకపోవడం': 'difficulty breathing', 'తల తిరగడం': 'dizziness',
        'బలహీనత': 'weakness', 'అలసట': 'fatigue',
        'దురద': 'itching', 'వాపు': 'swelling', 'నొప్పి': 'pain',
        'ఒళ్లు నొప్పులు': 'body ache', 'గొంతు నొప్పి': 'sore throat',
    },
    'ta': {
        'தலைவலி': 'headache', 'காய்ச்சல்': 'fever', 'இருமல்': 'cough',
        'சளி': 'cold', 'வாந்தி': 'vomiting', 'வயிற்றுப்போக்கு': 'diarrhea',
        'வயிற்று வலி': 'stomach pain', 'நெஞ்சு வலி': 'chest pain',
        'மூச்சு திணறல்': 'difficulty breathing', 'தலைச்சுற்றல்': 'dizziness',
        'பலவீனம்': 'weakness', 'சோர்வு': 'fatigue',
        'அரிப்பு': 'itching', 'வீக்கம்': 'swelling', 'வலி': 'pain',
    },
    'ml': {
        'തലവേദന': 'headache', 'പനി': 'fever', 'ചുമ': 'cough',
        'ജലദോഷം': 'cold', 'ഛർദ്ദി': 'vomiting', 'വയറിളക്കം': 'diarrhea',
        'വയറുവേദന': 'stomach pain', 'നെഞ്ചുവേദന': 'chest pain',
        'ശ്വാസംമുട്ടൽ': 'difficulty breathing', 'തലചുറ്റൽ': 'dizziness',
        'ക്ഷീണം': 'fatigue', 'ചൊറിച്ചിൽ': 'itching', 'വേദന': 'pain',
    },
    'mr': {
        'डोकेदुखी': 'headache', 'ताप': 'fever', 'खोकला': 'cough',
        'सर्दी': 'cold', 'उलटी': 'vomiting', 'जुलाब': 'diarrhea',
        'पोटदुखी': 'stomach pain', 'छातीत दुखणे': 'chest pain',
        'श्वास घेण्यास त्रास': 'difficulty breathing', 'चक्कर': 'dizziness',
        'अशक्तपणा': 'weakness', 'खाज': 'itching', 'वेदना': 'pain',
    },
    'gu': {
        'માથાનો દુખાવો': 'headache', 'તાવ': 'fever', 'ઉધરસ': 'cough',
        'શરદી': 'cold', 'ઉલટી': 'vomiting', 'ઝાડા': 'diarrhea',
        'પેટનો દુખાવો': 'stomach pain', 'છાતીમાં દુખાવો': 'chest pain',
        'શ્વાસ લેવામાં તકલીફ': 'difficulty breathing', 'ચક્કર': 'dizziness',
        'નબળાઈ': 'weakness', 'ખંજવાળ': 'itching', 'દુખાવો': 'pain',
    },
    'es': {
        'dolor de cabeza': 'headache', 'fiebre': 'fever', 'tos': 'cough',
        'resfriado': 'cold', 'vómito': 'vomiting', 'diarrea': 'diarrhea',
        'dolor de estómago': 'stomach pain', 'dolor de pecho': 'chest pain',
        'dificultad para respirar': 'difficulty breathing', 'mareo': 'dizziness',
        'debilidad': 'weakness', 'fatiga': 'fatigue', 'picazón': 'itching',
        'hinchazón': 'swelling', 'dolor': 'pain', 'náuseas': 'nausea',
    }
};

class VoiceEngine {
    constructor(options = {}) {
        this.recognition = null;
        this.isRecording = false;
        this.currentLanguage = options.language || 'en';
        this.onTranscript = options.onTranscript || (() => {});
        this.onInterim = options.onInterim || (() => {});
        this.onStatusChange = options.onStatusChange || (() => {});
        this.onError = options.onError || (() => {});

        this.mediaRecorder = null;
        this.audioChunks = [];

        this._initSpeechRecognition();
    }

    _initSpeechRecognition() {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            this.onError('Speech Recognition not supported. Use Chrome browser.');
            return;
        }

        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.maxAlternatives = 1;

        this._setLanguage(this.currentLanguage);

        this.recognition.onstart = () => {
            this.isRecording = true;
            this.onStatusChange('recording');
        };

        this.recognition.onresult = (event) => {
            let interimTranscript = '';
            let finalTranscript = '';

            for (let i = event.resultIndex; i < event.results.length; i++) {
                const transcript = event.results[i][0].transcript;
                if (event.results[i].isFinal) {
                    finalTranscript += transcript;
                } else {
                    interimTranscript += transcript;
                }
            }

            if (interimTranscript) {
                this.onInterim(interimTranscript);
            }

            if (finalTranscript) {
                const translated = this.translateText(finalTranscript);
                this.onTranscript({
                    original: finalTranscript,
                    translated: translated,
                    language: this.currentLanguage,
                    timestamp: getNowTimestamp()
                });
            }
        };

        this.recognition.onerror = (event) => {
            if (event.error === 'no-speech') return; // ignore no-speech
            console.error('Speech recognition error:', event.error);
            this.onError(`Speech error: ${event.error}`);
        };

        this.recognition.onend = () => {
            if (this.isRecording) {
                // Auto-restart if still in recording mode
                try { this.recognition.start(); } catch (e) {}
            } else {
                this.onStatusChange('stopped');
            }
        };
    }

    _setLanguage(langKey) {
        const lang = LANGUAGES[langKey];
        if (lang && this.recognition) {
            this.recognition.lang = lang.code;
        }
        this.currentLanguage = langKey;
    }

    setLanguage(langKey) {
        this._setLanguage(langKey);
        if (this.isRecording) {
            this.stop();
            setTimeout(() => this.start(), 300);
        }
    }

    start() {
        if (!this.recognition) {
            this.onError('Speech Recognition not available');
            return;
        }
        try {
            this.recognition.start();
            this._startAudioRecording();
        } catch (e) {
            console.error('Failed to start recognition:', e);
        }
    }

    stop() {
        this.isRecording = false;
        if (this.recognition) {
            try { this.recognition.stop(); } catch (e) {}
        }
        this._stopAudioRecording();
        this.onStatusChange('stopped');
    }

    translateText(text) {
        if (this.currentLanguage === 'en') return text;

        const dict = MEDICAL_DICT[this.currentLanguage];
        if (!dict) return text;

        let translated = text;
        // Sort by length (longest match first)
        const sortedEntries = Object.entries(dict).sort((a, b) => b[0].length - a[0].length);
        for (const [term, english] of sortedEntries) {
            translated = translated.replace(new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'), english);
        }
        return translated;
    }

    // ── Text-to-Speech ──
    speak(text, lang = 'en-US') {
        if (!window.speechSynthesis) return;

        // Cancel any ongoing speech
        window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = lang;
        utterance.rate = 0.9;
        utterance.pitch = 1;
        utterance.volume = 1;

        // Try to find an English voice
        const voices = window.speechSynthesis.getVoices();
        const englishVoice = voices.find(v => v.lang.startsWith('en'));
        if (englishVoice) utterance.voice = englishVoice;

        window.speechSynthesis.speak(utterance);
    }

    stopSpeaking() {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
    }

    // ── Audio Recording (WebM) ──
    async _startAudioRecording() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            this.mediaRecorder = new MediaRecorder(stream);
            this.audioChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                this.audioChunks.push(event.data);
            };

            this.mediaRecorder.start(1000); // chunk every second
        } catch (e) {
            console.warn('Audio recording not available:', e);
        }
    }

    _stopAudioRecording() {
        if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
            this.mediaRecorder.stop();
            this.mediaRecorder.stream.getTracks().forEach(t => t.stop());
        }
    }

    downloadAudio() {
        if (this.audioChunks.length === 0) return;
        const blob = new Blob(this.audioChunks, { type: 'audio/webm' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `consultation_audio_${Date.now()}.webm`;
        a.click();
        URL.revokeObjectURL(url);
    }

    // ── Static helpers ──
    static getLanguages() {
        return LANGUAGES;
    }

    static populateLanguageSelector(selectElement) {
        selectElement.innerHTML = '';
        for (const [key, lang] of Object.entries(LANGUAGES)) {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = `${lang.flag} ${lang.name}`;
            selectElement.appendChild(option);
        }
    }
}

// Ensure voices are loaded (Chrome lazy-loads them)
if (window.speechSynthesis) {
    window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices();
    };
}
