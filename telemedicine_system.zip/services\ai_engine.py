"""
AI Engine — Symptom Analysis, Urgency Detection, Medicine Verification,
Diet Suggestions, and Medical Disclaimer Logic.

This uses rule-based / keyword matching (college-safe, no API keys needed).
Architecture is pluggable — can swap in OpenAI/Azure ML later.
"""

import re

# ═══════════════════════════════════════════════════════════════
# URGENCY DETECTION
# ═══════════════════════════════════════════════════════════════

URGENCY_KEYWORDS = {
    'critical': [
        'chest pain', 'heart attack', 'stroke', 'unconscious', 'not breathing',
        'severe bleeding', 'seizure', 'choking', 'anaphylaxis', 'cardiac arrest',
        'collapsed', 'no pulse', 'poisoning', 'overdose', 'coma'
    ],
    'high': [
        'difficulty breathing', 'shortness of breath', 'high fever',
        'severe headache', 'vomiting blood', 'heavy bleeding', 'fracture',
        'burn', 'allergic reaction', 'fainting', 'blood in stool',
        'sudden vision loss', 'suicidal', 'severe pain', 'paralysis'
    ],
    'medium': [
        'persistent cough', 'mild fever', 'dizziness', 'nausea', 'vomiting',
        'diarrhea', 'rash', 'swelling', 'numbness', 'joint pain',
        'ear pain', 'sore throat', 'urinary pain', 'abdominal pain'
    ]
}


def detect_urgency(transcript):
    """
    Analyze transcript for urgency indicators.
    Returns: { is_urgent, severity, keywords_found, alert_message }
    """
    if not transcript:
        return {'is_urgent': False, 'severity': 'low', 'keywords_found': [], 'alert_message': ''}

    text = transcript.lower()
    found = {'critical': [], 'high': [], 'medium': []}

    for severity, keywords in URGENCY_KEYWORDS.items():
        for kw in keywords:
            if kw in text:
                found[severity].append(kw)

    if found['critical']:
        return {
            'is_urgent': True,
            'severity': 'critical',
            'keywords_found': found['critical'],
            'alert_message': f"🚨 CRITICAL EMERGENCY: {', '.join(found['critical'])}. Immediate attention required!"
        }
    elif found['high']:
        return {
            'is_urgent': True,
            'severity': 'high',
            'keywords_found': found['high'],
            'alert_message': f"⚠️ HIGH URGENCY: {', '.join(found['high'])}. Priority consultation needed."
        }
    elif found['medium']:
        return {
            'is_urgent': False,
            'severity': 'medium',
            'keywords_found': found['medium'],
            'alert_message': f"ℹ️ Moderate symptoms detected: {', '.join(found['medium'])}"
        }

    return {'is_urgent': False, 'severity': 'low', 'keywords_found': [], 'alert_message': ''}


# ═══════════════════════════════════════════════════════════════
# SYMPTOM ANALYSIS & DIAGNOSIS
# ═══════════════════════════════════════════════════════════════

SYMPTOM_PATTERNS = {
    'common_cold': {
        'symptoms': ['cough', 'runny nose', 'sneezing', 'sore throat', 'mild fever', 'congestion'],
        'disease': 'Common Cold (Acute Viral Nasopharyngitis)',
        'cause': 'Viral infection (Rhinovirus, Coronavirus)',
        'precautions': [
            'Stay hydrated — drink warm fluids',
            'Rest adequately (7-8 hours sleep)',
            'Cover mouth when coughing/sneezing',
            'Wash hands frequently',
            'Avoid cold beverages'
        ],
        'confidence': 0.75
    },
    'flu': {
        'symptoms': ['fever', 'body ache', 'fatigue', 'cough', 'headache', 'chills', 'muscle pain'],
        'disease': 'Influenza (Seasonal Flu)',
        'cause': 'Influenza virus (Type A/B)',
        'precautions': [
            'Complete bed rest for 3-5 days',
            'Stay hydrated',
            'Take prescribed antipyretics for fever',
            'Isolate to prevent spread',
            'Monitor temperature regularly'
        ],
        'confidence': 0.70
    },
    'gastritis': {
        'symptoms': ['stomach pain', 'nausea', 'vomiting', 'bloating', 'acidity', 'burning sensation', 'indigestion'],
        'disease': 'Acute Gastritis',
        'cause': 'H. pylori infection, excessive NSAID use, stress, or dietary factors',
        'precautions': [
            'Avoid spicy and oily food',
            'Eat small, frequent meals',
            'Avoid alcohol and caffeine',
            'Do not skip meals',
            'Manage stress levels'
        ],
        'confidence': 0.65
    },
    'migraine': {
        'symptoms': ['severe headache', 'one side headache', 'nausea', 'light sensitivity', 'vision problems', 'throbbing pain'],
        'disease': 'Migraine',
        'cause': 'Neurological condition — triggers include stress, hormonal changes, certain foods',
        'precautions': [
            'Rest in a dark, quiet room',
            'Apply cold compress to forehead',
            'Maintain regular sleep schedule',
            'Identify and avoid personal triggers',
            'Stay hydrated'
        ],
        'confidence': 0.60
    },
    'hypertension': {
        'symptoms': ['high blood pressure', 'headache', 'dizziness', 'chest tightness', 'blurred vision', 'fatigue'],
        'disease': 'Hypertension (High Blood Pressure)',
        'cause': 'Genetic factors, high sodium diet, obesity, stress, sedentary lifestyle',
        'precautions': [
            'Reduce salt intake',
            'Exercise regularly (30 min/day)',
            'Monitor blood pressure daily',
            'Reduce stress',
            'Avoid smoking and alcohol'
        ],
        'confidence': 0.55
    },
    'diabetes_symptoms': {
        'symptoms': ['frequent urination', 'excessive thirst', 'weight loss', 'fatigue', 'blurred vision', 'slow healing'],
        'disease': 'Suspected Diabetes Mellitus',
        'cause': 'Insulin resistance (Type 2) or autoimmune destruction of beta cells (Type 1)',
        'precautions': [
            'Get blood sugar levels tested immediately',
            'Reduce sugar and refined carb intake',
            'Exercise regularly',
            'Monitor blood glucose',
            'Follow up with endocrinologist'
        ],
        'confidence': 0.50
    },
    'allergic_reaction': {
        'symptoms': ['rash', 'itching', 'hives', 'swelling', 'sneezing', 'watery eyes', 'skin redness'],
        'disease': 'Allergic Reaction (Urticaria / Allergic Rhinitis)',
        'cause': 'Immune system response to allergens (pollen, dust, food, medication)',
        'precautions': [
            'Identify and avoid allergen',
            'Take prescribed antihistamines',
            'Keep skin moisturized',
            'Avoid scratching',
            'Seek emergency care if breathing is affected'
        ],
        'confidence': 0.65
    },
    'uti': {
        'symptoms': ['burning urination', 'frequent urination', 'lower abdominal pain', 'cloudy urine', 'urinary pain', 'pelvic pain'],
        'disease': 'Urinary Tract Infection (UTI)',
        'cause': 'Bacterial infection (commonly E. coli)',
        'precautions': [
            'Drink plenty of water',
            'Complete the full course of antibiotics',
            'Maintain proper hygiene',
            'Urinate frequently — do not hold',
            'Avoid irritating feminine products'
        ],
        'confidence': 0.70
    },
    'respiratory_infection': {
        'symptoms': ['cough', 'chest pain', 'difficulty breathing', 'wheezing', 'phlegm', 'fever'],
        'disease': 'Lower Respiratory Tract Infection',
        'cause': 'Bacterial or viral infection affecting bronchi or lungs',
        'precautions': [
            'Seek medical attention immediately',
            'Complete prescribed antibiotics course',
            'Use steam inhalation',
            'Avoid dust and smoke',
            'Rest adequately'
        ],
        'confidence': 0.60
    },
    'anxiety_stress': {
        'symptoms': ['anxiety', 'palpitations', 'sweating', 'trembling', 'insomnia', 'restlessness', 'panic'],
        'disease': 'Anxiety Disorder / Stress-Related Condition',
        'cause': 'Psychological stress, trauma, genetic predisposition',
        'precautions': [
            'Practice deep breathing exercises',
            'Maintain regular exercise routine',
            'Limit caffeine and alcohol',
            'Establish a regular sleep schedule',
            'Consider professional counseling'
        ],
        'confidence': 0.55
    }
}


def analyze_symptoms(transcript):
    """
    Analyze transcript to detect symptoms and suggest diagnosis.
    Returns: { symptoms, diagnosis, cause, precautions, confidence, problem }
    """
    if not transcript:
        return {
            'symptoms': [],
            'diagnosis': '',
            'cause': '',
            'precautions': [],
            'confidence': 0,
            'problem': 'No transcript available for analysis'
        }

    text = transcript.lower()
    best_match = None
    best_score = 0

    for pattern_key, pattern in SYMPTOM_PATTERNS.items():
        matched_symptoms = []
        for symptom in pattern['symptoms']:
            # Check for symptom keywords in transcript
            if symptom in text:
                matched_symptoms.append(symptom)
            else:
                # Check individual words
                words = symptom.split()
                if len(words) > 1 and all(w in text for w in words):
                    matched_symptoms.append(symptom)

        if len(matched_symptoms) >= 2:
            score = len(matched_symptoms) / len(pattern['symptoms'])
            if score > best_score:
                best_score = score
                best_match = {
                    'symptoms': matched_symptoms,
                    'diagnosis': pattern['disease'],
                    'cause': pattern['cause'],
                    'precautions': pattern['precautions'],
                    'confidence': min(pattern['confidence'] * (1 + score), 0.95),
                    'problem': f"Patient presenting with {', '.join(matched_symptoms)}"
                }

    if best_match:
        return best_match

    # Extract any recognizable symptoms even without a pattern match
    all_symptoms = set()
    for pattern in SYMPTOM_PATTERNS.values():
        for symptom in pattern['symptoms']:
            if symptom in text:
                all_symptoms.add(symptom)

    return {
        'symptoms': list(all_symptoms),
        'diagnosis': 'Requires further clinical evaluation',
        'cause': 'Unable to determine from available information',
        'precautions': ['Follow up with specialist', 'Get diagnostic tests done', 'Monitor symptoms'],
        'confidence': 0.2 if all_symptoms else 0,
        'problem': f"Patient reports: {', '.join(all_symptoms)}" if all_symptoms else 'Symptoms not clearly identified from transcript'
    }


# ═══════════════════════════════════════════════════════════════
# MEDICINE VERIFICATION
# ═══════════════════════════════════════════════════════════════

MEDICINE_DB = {
    'paracetamol': {
        'generic': 'Acetaminophen',
        'dosage_range': '325mg - 1000mg',
        'max_daily': '4000mg',
        'frequency': 'Every 4-6 hours',
        'max_per_day': 4,
        'category': 'Analgesic/Antipyretic',
        'warnings': ['Do not exceed 4g/day', 'Avoid with liver disease', 'Avoid alcohol']
    },
    'amoxicillin': {
        'generic': 'Amoxicillin',
        'dosage_range': '250mg - 500mg',
        'max_daily': '3000mg',
        'frequency': 'Every 8 hours',
        'max_per_day': 3,
        'category': 'Antibiotic (Penicillin)',
        'warnings': ['Complete full course', 'Check for penicillin allergy', 'Take with food']
    },
    'ibuprofen': {
        'generic': 'Ibuprofen',
        'dosage_range': '200mg - 400mg',
        'max_daily': '1200mg (OTC)',
        'frequency': 'Every 6-8 hours',
        'max_per_day': 3,
        'category': 'NSAID',
        'warnings': ['Take with food', 'Avoid with kidney disease', 'Not for pregnant women']
    },
    'cetirizine': {
        'generic': 'Cetirizine Hydrochloride',
        'dosage_range': '5mg - 10mg',
        'max_daily': '10mg',
        'frequency': 'Once daily',
        'max_per_day': 1,
        'category': 'Antihistamine',
        'warnings': ['May cause drowsiness', 'Avoid driving after taking']
    },
    'omeprazole': {
        'generic': 'Omeprazole',
        'dosage_range': '20mg - 40mg',
        'max_daily': '40mg',
        'frequency': 'Once daily before meal',
        'max_per_day': 1,
        'category': 'Proton Pump Inhibitor',
        'warnings': ['Take 30 min before food', 'Long-term use may affect calcium absorption']
    },
    'metformin': {
        'generic': 'Metformin Hydrochloride',
        'dosage_range': '500mg - 1000mg',
        'max_daily': '2000mg',
        'frequency': 'Twice daily with meals',
        'max_per_day': 2,
        'category': 'Antidiabetic',
        'warnings': ['Take with food', 'Monitor blood sugar', 'Avoid alcohol']
    },
    'amlodipine': {
        'generic': 'Amlodipine Besylate',
        'dosage_range': '2.5mg - 10mg',
        'max_daily': '10mg',
        'frequency': 'Once daily',
        'max_per_day': 1,
        'category': 'Calcium Channel Blocker (Antihypertensive)',
        'warnings': ['May cause ankle swelling', 'Monitor blood pressure regularly']
    },
    'azithromycin': {
        'generic': 'Azithromycin',
        'dosage_range': '250mg - 500mg',
        'max_daily': '500mg',
        'frequency': 'Once daily for 3-5 days',
        'max_per_day': 1,
        'category': 'Antibiotic (Macrolide)',
        'warnings': ['Complete full course', 'Take 1 hour before food', 'Check for allergies']
    },
    'pantoprazole': {
        'generic': 'Pantoprazole',
        'dosage_range': '20mg - 40mg',
        'max_daily': '80mg',
        'frequency': 'Once daily before breakfast',
        'max_per_day': 2,
        'category': 'Proton Pump Inhibitor',
        'warnings': ['Take before meals', 'Do not crush tablets']
    },
    'dolo 650': {
        'generic': 'Paracetamol 650mg',
        'dosage_range': '650mg',
        'max_daily': '2600mg',
        'frequency': 'Every 4-6 hours',
        'max_per_day': 4,
        'category': 'Analgesic/Antipyretic',
        'warnings': ['Do not exceed 4 tablets/day', 'Avoid with liver issues']
    },
    'montelukast': {
        'generic': 'Montelukast Sodium',
        'dosage_range': '10mg',
        'max_daily': '10mg',
        'frequency': 'Once daily at bedtime',
        'max_per_day': 1,
        'category': 'Leukotriene Receptor Antagonist',
        'warnings': ['Take at night', 'Monitor mood changes']
    },
    'salbutamol': {
        'generic': 'Salbutamol / Albuterol',
        'dosage_range': '100mcg - 200mcg (inhaler)',
        'max_daily': '800mcg',
        'frequency': 'As needed, max 4 times/day',
        'max_per_day': 4,
        'category': 'Bronchodilator',
        'warnings': ['Do not exceed recommended puffs', 'Rinse mouth after use']
    },
    'crocin': {
        'generic': 'Paracetamol',
        'dosage_range': '500mg - 650mg',
        'max_daily': '2600mg',
        'frequency': 'Every 4-6 hours',
        'max_per_day': 4,
        'category': 'Analgesic/Antipyretic',
        'warnings': ['Do not exceed 4 tablets/day', 'Avoid with liver disease']
    },
    'ciprofloxacin': {
        'generic': 'Ciprofloxacin',
        'dosage_range': '250mg - 500mg',
        'max_daily': '1000mg',
        'frequency': 'Twice daily',
        'max_per_day': 2,
        'category': 'Antibiotic (Fluoroquinolone)',
        'warnings': ['Complete full course', 'Avoid dairy while taking', 'May cause tendon issues']
    },
    'diclofenac': {
        'generic': 'Diclofenac Sodium',
        'dosage_range': '50mg - 100mg',
        'max_daily': '150mg',
        'frequency': '2-3 times daily',
        'max_per_day': 3,
        'category': 'NSAID',
        'warnings': ['Take with food', 'Avoid long-term use', 'Not for heart patients']
    }
}


def verify_medicine(name, dosage=''):
    """
    Verify if a medicine name is valid and dosage is within range.
    Returns: { valid, medicine_info, warnings, suggested_dosage }
    """
    name_lower = name.lower().strip()

    # Direct match
    if name_lower in MEDICINE_DB:
        info = MEDICINE_DB[name_lower]
        return {
            'valid': True,
            'name': name,
            'generic_name': info['generic'],
            'category': info['category'],
            'suggested_dosage': info['dosage_range'],
            'frequency': info['frequency'],
            'max_daily': info['max_daily'],
            'warnings': info['warnings']
        }

    # Partial match
    for med_name, info in MEDICINE_DB.items():
        if name_lower in med_name or med_name in name_lower or name_lower in info['generic'].lower():
            return {
                'valid': True,
                'name': med_name.title(),
                'generic_name': info['generic'],
                'category': info['category'],
                'suggested_dosage': info['dosage_range'],
                'frequency': info['frequency'],
                'max_daily': info['max_daily'],
                'warnings': info['warnings']
            }

    return {
        'valid': False,
        'name': name,
        'generic_name': 'Unknown',
        'category': 'Unverified',
        'suggested_dosage': 'Consult pharmacopeia',
        'frequency': 'As prescribed',
        'max_daily': 'N/A',
        'warnings': ['Medicine not found in database — verify manually before prescribing']
    }


# ═══════════════════════════════════════════════════════════════
# AI PRESCRIPTION SUGGESTIONS
# ═══════════════════════════════════════════════════════════════

DIAGNOSIS_PRESCRIPTIONS = {
    'Common Cold': [
        {'name': 'Paracetamol', 'dosage': '500mg', 'frequency': 'Thrice daily', 'duration': '3 days'},
        {'name': 'Cetirizine', 'dosage': '10mg', 'frequency': 'Once daily', 'duration': '5 days'},
    ],
    'Influenza': [
        {'name': 'Paracetamol', 'dosage': '650mg', 'frequency': 'Thrice daily', 'duration': '5 days'},
        {'name': 'Cetirizine', 'dosage': '10mg', 'frequency': 'Once daily', 'duration': '5 days'},
        {'name': 'Amoxicillin', 'dosage': '500mg', 'frequency': 'Thrice daily', 'duration': '5 days'},
    ],
    'Acute Gastritis': [
        {'name': 'Pantoprazole', 'dosage': '40mg', 'frequency': 'Once daily', 'duration': '14 days'},
        {'name': 'Domperidone', 'dosage': '10mg', 'frequency': 'Thrice daily', 'duration': '7 days'},
    ],
    'Migraine': [
        {'name': 'Ibuprofen', 'dosage': '400mg', 'frequency': 'As needed', 'duration': 'When symptomatic'},
        {'name': 'Paracetamol', 'dosage': '1000mg', 'frequency': 'As needed', 'duration': 'When symptomatic'},
    ],
    'Urinary Tract Infection': [
        {'name': 'Ciprofloxacin', 'dosage': '500mg', 'frequency': 'Twice daily', 'duration': '5 days'},
        {'name': 'Paracetamol', 'dosage': '500mg', 'frequency': 'As needed', 'duration': '3 days'},
    ],
    'Allergic Reaction': [
        {'name': 'Cetirizine', 'dosage': '10mg', 'frequency': 'Once daily', 'duration': '7 days'},
        {'name': 'Montelukast', 'dosage': '10mg', 'frequency': 'Once at night', 'duration': '14 days'},
    ],
}


def suggest_prescription(diagnosis):
    """Suggest medicines based on diagnosis. Doctor can modify."""
    for key, meds in DIAGNOSIS_PRESCRIPTIONS.items():
        if key.lower() in diagnosis.lower():
            return {'suggestions': meds, 'note': 'AI-suggested. Doctor review required.'}
    return {'suggestions': [], 'note': 'No automated suggestions available for this diagnosis.'}


# ═══════════════════════════════════════════════════════════════
# DIET & EXERCISE SUGGESTIONS
# ═══════════════════════════════════════════════════════════════

DIET_PLANS = {
    'Common Cold': {
        'diet': [
            'Warm soups (chicken, vegetable)',
            'Citrus fruits (orange, lemon) for Vitamin C',
            'Ginger tea with honey',
            'Light, easily digestible meals',
            'Avoid cold drinks and ice cream'
        ],
        'exercise': [
            'Complete rest for first 2 days',
            'Light walking after symptoms reduce',
            'Deep breathing exercises',
            'Avoid strenuous activity until recovered'
        ]
    },
    'Influenza': {
        'diet': [
            'Clear broths and soups',
            'Stay hydrated — 3+ liters water/day',
            'Bananas and rice (BRAT diet if nauseous)',
            'Herbal teas with turmeric',
            'Avoid dairy if congested'
        ],
        'exercise': [
            'Strict bed rest for 3-5 days',
            'No exercise until fever-free for 24 hours',
            'Gentle stretching after recovery',
            'Gradual return to normal activity'
        ]
    },
    'Acute Gastritis': {
        'diet': [
            'Avoid spicy, fried, and acidic foods',
            'Small, frequent meals (5-6/day)',
            'Include probiotics (yogurt, buttermilk)',
            'Boiled vegetables and rice',
            'Avoid caffeine and carbonated drinks'
        ],
        'exercise': [
            'Light walking after meals (15 min)',
            'Yoga — especially Vajrasana after eating',
            'Avoid intense exercise on empty stomach',
            'Stress-reduction activities'
        ]
    },
    'Migraine': {
        'diet': [
            'Avoid trigger foods (cheese, chocolate, MSG)',
            'Maintain regular meal times',
            'Magnesium-rich foods (spinach, nuts)',
            'Stay well hydrated',
            'Limit caffeine to 1 cup/day'
        ],
        'exercise': [
            'Regular moderate exercise (30 min/day)',
            'Yoga and meditation',
            'Avoid sudden intense exertion',
            'Neck and shoulder stretches daily'
        ]
    },
    'Hypertension': {
        'diet': [
            'DASH diet — fruits, vegetables, whole grains',
            'Reduce sodium to < 2300mg/day',
            'Potassium-rich foods (bananas, potatoes)',
            'Limit red meat and saturated fats',
            'Avoid processed and canned foods'
        ],
        'exercise': [
            'Brisk walking 30-45 minutes daily',
            'Swimming or cycling',
            'Avoid heavy weightlifting',
            'Pranayama breathing exercises'
        ]
    },
    'Diabetes': {
        'diet': [
            'Low glycemic index foods',
            'High fiber — whole grains, vegetables',
            'Lean protein sources',
            'Avoid sugar, sweets, white rice',
            'Regular small meals'
        ],
        'exercise': [
            'Walking 30 minutes after meals',
            'Regular aerobic exercise',
            'Resistance training 2-3 times/week',
            'Yoga — especially Surya Namaskar'
        ]
    }
}


def suggest_diet(diagnosis):
    """Suggest diet and exercise plan based on diagnosis."""
    for key, plan in DIET_PLANS.items():
        if key.lower() in diagnosis.lower():
            return plan
    return {
        'diet': [
            'Balanced diet with fruits and vegetables',
            'Stay well hydrated (2-3 liters water/day)',
            'Avoid processed and junk food',
            'Include whole grains and lean protein'
        ],
        'exercise': [
            'Regular walking (30 minutes/day)',
            'Light stretching exercises',
            'Adequate sleep (7-8 hours)',
            'Stress management activities'
        ]
    }


# ═══════════════════════════════════════════════════════════════
# MEDICAL DISCLAIMER
# ═══════════════════════════════════════════════════════════════

def generate_disclaimer(confidence):
    """
    Generate appropriate medical disclaimer based on AI confidence level.
    """
    if confidence >= 0.7:
        return (
            "Note: This AI-assisted analysis is based on reported symptoms and should be "
            "used as a supportive tool only. Final diagnosis and treatment decisions must be "
            "made by the attending physician."
        )
    elif confidence >= 0.4:
        return (
            "Medical Disclaimer: AI analysis has moderate confidence in the assessment. "
            "Additional diagnostic tests and clinical examination are recommended before "
            "confirming the diagnosis. This is not a substitute for professional medical advice."
        )
    else:
        return (
            "⚠️ Medical Disclaimer: AI could not determine sufficient medical information from "
            "the available data. The patient should undergo proper clinical examination, "
            "diagnostic tests, and consultation with a specialist. This AI output should NOT "
            "be used as a basis for treatment decisions."
        )


# ═══════════════════════════════════════════════════════════════
# MULTILINGUAL MEDICAL TERM DICTIONARY
# ═══════════════════════════════════════════════════════════════

MEDICAL_TRANSLATIONS = {
    # Hindi (hi-IN)
    'hi': {
        'सिरदर्द': 'headache', 'बुखार': 'fever', 'खांसी': 'cough',
        'जुकाम': 'cold', 'उल्टी': 'vomiting', 'दस्त': 'diarrhea',
        'पेट दर्द': 'stomach pain', 'छाती में दर्द': 'chest pain',
        'सांस लेने में तकलीफ': 'difficulty breathing', 'चक्कर': 'dizziness',
        'कमजोरी': 'weakness', 'थकान': 'fatigue', 'जलन': 'burning sensation',
        'खुजली': 'itching', 'सूजन': 'swelling', 'दर्द': 'pain',
        'बदन दर्द': 'body ache', 'गले में खराश': 'sore throat',
        'नाक बहना': 'runny nose', 'पेशाब में जलन': 'burning urination',
        'भूख नहीं': 'loss of appetite', 'नींद नहीं': 'insomnia',
        'जी मिचलाना': 'nausea', 'कब्ज': 'constipation',
        'दवाई': 'medicine', 'डॉक्टर': 'doctor', 'अस्पताल': 'hospital',
        'ब्लड प्रेशर': 'blood pressure', 'शुगर': 'diabetes',
        'एलर्जी': 'allergy', 'चोट': 'injury', 'टीका': 'vaccine',
    },
    # Kannada (kn-IN)
    'kn': {
        'ತಲೆನೋವು': 'headache', 'ಜ್ವರ': 'fever', 'ಕೆಮ್ಮು': 'cough',
        'ನೆಗಡಿ': 'cold', 'ವಾಂತಿ': 'vomiting', 'ಭೇದಿ': 'diarrhea',
        'ಹೊಟ್ಟೆ ನೋವು': 'stomach pain', 'ಎದೆ ನೋವು': 'chest pain',
        'ಉಸಿರಾಟದ ತೊಂದರೆ': 'difficulty breathing', 'ತಲೆ ತಿರುಗುವಿಕೆ': 'dizziness',
        'ದೌರ್ಬಲ್ಯ': 'weakness', 'ಆಯಾಸ': 'fatigue', 'ಉರಿ': 'burning sensation',
        'ತುರಿಕೆ': 'itching', 'ಊತ': 'swelling', 'ನೋವು': 'pain',
        'ಮೈ ನೋವು': 'body ache', 'ಗಂಟಲು ನೋವು': 'sore throat',
        'ಮೂಗು ಸೋರುವಿಕೆ': 'runny nose', 'ಮೂತ್ರ ಉರಿ': 'burning urination',
        'ಹಸಿವಿಲ್ಲ': 'loss of appetite', 'ನಿದ್ರೆ ಬರುವುದಿಲ್ಲ': 'insomnia',
        'ಔಷಧಿ': 'medicine', 'ವೈದ್ಯರು': 'doctor', 'ಆಸ್ಪತ್ರೆ': 'hospital',
    },
    # Telugu (te-IN)
    'te': {
        'తలనొప్పి': 'headache', 'జ్వరం': 'fever', 'దగ్గు': 'cough',
        'జలుబు': 'cold', 'వాంతులు': 'vomiting', 'విరేచనాలు': 'diarrhea',
        'కడుపు నొప్పి': 'stomach pain', 'ఛాతీ నొప్పి': 'chest pain',
        'ఊపిరి ఆడకపోవడం': 'difficulty breathing', 'తల తిరగడం': 'dizziness',
        'బలహీనత': 'weakness', 'అలసట': 'fatigue', 'మంట': 'burning sensation',
        'దురద': 'itching', 'వాపు': 'swelling', 'నొప్పి': 'pain',
        'ఒళ్లు నొప్పులు': 'body ache', 'గొంతు నొప్పి': 'sore throat',
        'ముక్కు కారడం': 'runny nose', 'మూత్రం మంట': 'burning urination',
        'ఆకలి లేదు': 'loss of appetite', 'నిద్ర రాకపోవడం': 'insomnia',
        'మందు': 'medicine', 'డాక్టర్': 'doctor', 'ఆసుపత్రి': 'hospital',
    },
    # Tamil (ta-IN)
    'ta': {
        'தலைவலி': 'headache', 'காய்ச்சல்': 'fever', 'இருமல்': 'cough',
        'சளி': 'cold', 'வாந்தி': 'vomiting', 'வயிற்றுப்போக்கு': 'diarrhea',
        'வயிற்று வலி': 'stomach pain', 'நெஞ்சு வலி': 'chest pain',
        'மூச்சு திணறல்': 'difficulty breathing', 'தலைச்சுற்றல்': 'dizziness',
        'பலவீனம்': 'weakness', 'சோர்வு': 'fatigue', 'எரிச்சல்': 'burning sensation',
        'அரிப்பு': 'itching', 'வீக்கம்': 'swelling', 'வலி': 'pain',
        'உடல் வலி': 'body ache', 'தொண்டை வலி': 'sore throat',
        'மூக்கு ஒழுகுதல்': 'runny nose', 'சிறுநீர் எரிச்சல்': 'burning urination',
        'பசி இல்லை': 'loss of appetite', 'தூக்கமின்மை': 'insomnia',
        'மருந்து': 'medicine', 'மருத்துவர்': 'doctor', 'மருத்துவமனை': 'hospital',
    },
    # Malayalam (ml-IN)
    'ml': {
        'തലവേദന': 'headache', 'പനി': 'fever', 'ചുമ': 'cough',
        'ജലദോഷം': 'cold', 'ഛർദ്ദി': 'vomiting', 'വയറിളക്കം': 'diarrhea',
        'വയറുവേദന': 'stomach pain', 'നെഞ്ചുവേദന': 'chest pain',
        'ശ്വാസംമുട്ടൽ': 'difficulty breathing', 'തലചുറ്റൽ': 'dizziness',
        'ബലഹീനത': 'weakness', 'ക്ഷീണം': 'fatigue', 'നീറ്റൽ': 'burning sensation',
        'ചൊറിച്ചിൽ': 'itching', 'നീർക്കെട്ട്': 'swelling', 'വേദന': 'pain',
        'ശരീരവേദന': 'body ache', 'തൊണ്ടവേദന': 'sore throat',
        'മൂക്കൊലിപ്പ്': 'runny nose', 'മൂത്രത്തിൽ നീറ്റൽ': 'burning urination',
        'വിശപ്പില്ല': 'loss of appetite', 'ഉറക്കമില്ല': 'insomnia',
        'മരുന്ന്': 'medicine', 'ഡോക്ടർ': 'doctor', 'ആശുപത്രി': 'hospital',
    },
    # Marathi (mr-IN)
    'mr': {
        'डोकेदुखी': 'headache', 'ताप': 'fever', 'खोकला': 'cough',
        'सर्दी': 'cold', 'उलटी': 'vomiting', 'जुलाब': 'diarrhea',
        'पोटदुखी': 'stomach pain', 'छातीत दुखणे': 'chest pain',
        'श्वास घेण्यास त्रास': 'difficulty breathing', 'चक्कर': 'dizziness',
        'अशक्तपणा': 'weakness', 'थकवा': 'fatigue', 'जळजळ': 'burning sensation',
        'खाज': 'itching', 'सूज': 'swelling', 'वेदना': 'pain',
        'अंगदुखी': 'body ache', 'घसा दुखणे': 'sore throat',
        'नाक वाहणे': 'runny nose', 'लघवी करताना जळजळ': 'burning urination',
        'भूक नाही': 'loss of appetite', 'झोप येत नाही': 'insomnia',
        'औषध': 'medicine', 'डॉक्टर': 'doctor', 'रुग्णालय': 'hospital',
    },
    # Gujarati (gu-IN)
    'gu': {
        'માથાનો દુખાવો': 'headache', 'તાવ': 'fever', 'ઉધરસ': 'cough',
        'શરદી': 'cold', 'ઉલટી': 'vomiting', 'ઝાડા': 'diarrhea',
        'પેટનો દુખાવો': 'stomach pain', 'છાતીમાં દુખાવો': 'chest pain',
        'શ્વાસ લેવામાં તકલીફ': 'difficulty breathing', 'ચક્કર': 'dizziness',
        'નબળાઈ': 'weakness', 'થાક': 'fatigue', 'બળતરા': 'burning sensation',
        'ખંજવાળ': 'itching', 'સોજો': 'swelling', 'દુખાવો': 'pain',
        'શરીરનો દુખાવો': 'body ache', 'ગળામાં દુખાવો': 'sore throat',
        'નાક વહેવું': 'runny nose', 'પેશાબમાં બળતરા': 'burning urination',
        'ભૂખ નથી લાગતી': 'loss of appetite', 'ઊંઘ નથી આવતી': 'insomnia',
        'દવા': 'medicine', 'ડૉક્ટર': 'doctor', 'હૉસ્પિટલ': 'hospital',
    },
    # Tulu (closest to Kannada, no standard ASR code)
    'tulu': {
        'ತರೆ ನೋವು': 'headache', 'ಜ್ವರ': 'fever', 'ಕೆಮ್ಮು': 'cough',
        'ನೆಗಡಿ': 'cold', 'ಆಕರ': 'vomiting', 'ಭೇದಿ': 'diarrhea',
        'ಬಂಜಿ ನೋವು': 'stomach pain', 'ಎದೆ ನೋವು': 'chest pain',
        'ಉಸಿರ್ ಕಷ್ಟ': 'difficulty breathing', 'ತರೆ ಗಿರ್ಗಿರ್': 'dizziness',
        'ನೋವು': 'pain', 'ಮೈ ನೋವು': 'body ache', 'ಗಂಟಲ್ ನೋವು': 'sore throat',
        'ಮರ್ದ್': 'medicine', 'ಡಾಕ್ಟ್ರ': 'doctor',
    },
    # Bhojpuri (closest to Hindi, no standard ASR code)
    'bho': {
        'माथा दुखात बा': 'headache', 'बोखार': 'fever', 'खाँसी': 'cough',
        'जुकाम': 'cold', 'उलटी': 'vomiting', 'दस्त': 'diarrhea',
        'पेट दुखात बा': 'stomach pain', 'छाती में दरद': 'chest pain',
        'साँस में तकलीफ': 'difficulty breathing', 'चक्कर': 'dizziness',
        'कमजोरी': 'weakness', 'थकान': 'fatigue', 'जरन': 'burning sensation',
        'खुजली': 'itching', 'सुजन': 'swelling', 'दरद': 'pain',
        'बदन दरद': 'body ache', 'गला में खराश': 'sore throat',
        'दवाई': 'medicine', 'डाक्टर': 'doctor', 'अस्पताल': 'hospital',
    },
    # Spanish (es-ES)
    'es': {
        'dolor de cabeza': 'headache', 'fiebre': 'fever', 'tos': 'cough',
        'resfriado': 'cold', 'vómito': 'vomiting', 'diarrea': 'diarrhea',
        'dolor de estómago': 'stomach pain', 'dolor de pecho': 'chest pain',
        'dificultad para respirar': 'difficulty breathing', 'mareo': 'dizziness',
        'debilidad': 'weakness', 'fatiga': 'fatigue', 'ardor': 'burning sensation',
        'picazón': 'itching', 'hinchazón': 'swelling', 'dolor': 'pain',
        'dolor de cuerpo': 'body ache', 'dolor de garganta': 'sore throat',
        'nariz congestionada': 'runny nose', 'ardor al orinar': 'burning urination',
        'falta de apetito': 'loss of appetite', 'insomnio': 'insomnia',
        'medicina': 'medicine', 'doctor': 'doctor', 'hospital': 'hospital',
        'náuseas': 'nausea', 'alergia': 'allergy', 'presión arterial': 'blood pressure',
    }
}


def translate_medical_terms(text, source_lang):
    """
    Translate medical terms from source language to English.
    Non-medical text is passed through as-is.
    """
    if source_lang == 'en' or source_lang not in MEDICAL_TRANSLATIONS:
        return text

    dictionary = MEDICAL_TRANSLATIONS[source_lang]
    translated = text

    # Sort by length (longest first) to handle compound terms first
    sorted_terms = sorted(dictionary.items(), key=lambda x: len(x[0]), reverse=True)
    for term, english in sorted_terms:
        translated = translated.replace(term, english)

    return translated


def get_supported_languages():
    """Return list of supported languages with their codes."""
    return {
        'en': {'name': 'English', 'speech_code': 'en-US'},
        'hi': {'name': 'Hindi', 'speech_code': 'hi-IN'},
        'kn': {'name': 'Kannada', 'speech_code': 'kn-IN'},
        'te': {'name': 'Telugu', 'speech_code': 'te-IN'},
        'ta': {'name': 'Tamil', 'speech_code': 'ta-IN'},
        'ml': {'name': 'Malayalam', 'speech_code': 'ml-IN'},
        'mr': {'name': 'Marathi', 'speech_code': 'mr-IN'},
        'gu': {'name': 'Gujarati', 'speech_code': 'gu-IN'},
        'tulu': {'name': 'Tulu', 'speech_code': 'kn-IN'},
        'bho': {'name': 'Bhojpuri', 'speech_code': 'hi-IN'},
        'es': {'name': 'Spanish', 'speech_code': 'es-ES'},
    }
