/**
 * ═══════════════════════════════════════════════════════════════
 * Doctor Dashboard — Main Logic
 * Notifications, consultation view, prescription editor,
 * AI analysis, report generation, history
 * ═══════════════════════════════════════════════════════════════
 */

let socket = null;
let voiceEngine = null;
let currentConsultation = null;
let currentPrescriptionId = null;
let auth = null;
let doctorInfo = null;
let medicineRowCount = 0;
let notifPollTimer = null;

document.addEventListener('DOMContentLoaded', () => {
    auth = requireAuth('doctor');
    if (!auth) return;

    document.getElementById('doctor-name').textContent = auth.user.name;
    document.getElementById('welcome-title').textContent = `Welcome, ${auth.user.name}`;

    VoiceEngine.populateLanguageSelector(document.getElementById('doc-language-select'));

    // Connect WebSocket
    initSocket();

    // Add initial medicine row
    addMedicineRow();

    // Start polling for notifications
    checkNotifications();
    notifPollTimer = setInterval(checkNotifications, 5000);

    // Load stats
    loadDoctorStats();
});

// ═══ SOCKET ═══
function initSocket() {
    try {
        socket = io(API_BASE, { transports: ['websocket', 'polling'] });

        socket.on('connect', () => {
            console.log('✅ Doctor WebSocket connected');
            socket.emit('join_lobby');

            // Join doctor-specific room
            if (auth.user.role_id) {
                socket.emit('join_doctor_room', { doctor_id: auth.user.role_id });
            }
        });

        socket.on('patient_request', (data) => {
            showToast('A patient wants to consult with you!', 'warning', 6000);
            checkNotifications();
        });

        socket.on('new_message', (data) => {
            if (data.speaker === 'patient') {
                addDoctorTranscriptMessage('patient', data.text, data.original_text, data.timestamp);

                // Check urgency
                if (data.urgency && data.urgency.is_urgent) {
                    showDoctorUrgencyAlert(data.urgency);
                }
            }
        });

        socket.on('urgency_alert', (data) => {
            showDoctorUrgencyAlert(data);
            showToast(data.message, 'error', 8000);
        });

        socket.on('user_typing', (data) => {
            // Could show patient typing indicator
        });

        socket.on('consultation_ended', () => {
            showToast('Patient ended the consultation', 'info');
        });

        socket.on('disconnect', () => {
            console.log('❌ Doctor WebSocket disconnected');
        });
    } catch (e) {
        console.warn('WebSocket not available:', e);
    }
}

// ═══ NOTIFICATIONS ═══
async function checkNotifications() {
    try {
        const result = await apiCall('/doctors/notifications');
        if (result && result.has_notification && result.patient) {
            showNotificationBadge(result.patient);
        }
    } catch (e) {}
}

function showNotificationBadge(patient) {
    const badge = document.getElementById('notif-badge');
    badge.classList.remove('hidden');
    badge.textContent = '1';

    const content = document.getElementById('notif-content');
    content.innerHTML = `
        <div style="padding: 0.5rem 0;">
            <p style="font-weight: 600; font-size: 1rem; margin-bottom: 0.25rem;">${escapeHtml(patient.name || 'Patient')}</p>
            <p class="text-sm text-muted">
                ${patient.age ? `Age: ${patient.age}` : ''} 
                ${patient.gender ? `| ${patient.gender}` : ''} 
                ${patient.blood_group ? `| Blood: ${patient.blood_group}` : ''}
            </p>
            <p class="text-sm mt-sm" style="color: var(--accent-secondary);">Wants to consult with you</p>
            <div class="flex gap-sm mt-md">
                <button class="btn btn-success btn-sm" onclick="acceptPatient(${patient.id})" style="flex: 1;">
                    <i class="fas fa-check"></i> Accept
                </button>
                <button class="btn btn-ghost btn-sm" onclick="declinePatient()" style="flex: 1;">
                    <i class="fas fa-times"></i> Decline
                </button>
            </div>
        </div>
    `;
}

function toggleNotificationPanel() {
    document.getElementById('notif-popup').classList.toggle('active');
}

async function acceptPatient(patientId) {
    toggleNotificationPanel();
    document.getElementById('notif-badge').classList.add('hidden');

    try {
        // Clear notification
        await apiCall('/doctors/notifications/clear', 'POST');

        // Check for active consultation
        const active = await apiCall('/consult/active');
        if (active && active.id) {
            currentConsultation = active;
            showConsultationView(active);
            return;
        }

        // Start consultation
        const result = await apiCall('/consult/start', 'POST', {
            patient_id: patientId,
            doctor_id: auth.user.role_id || 1
        });

        if (result && result.consultation_id) {
            // Fetch full consultation details
            const consultation = await apiCall(`/consult/${result.consultation_id}`);
            currentConsultation = consultation || { id: result.consultation_id };

            if (socket) {
                socket.emit('join_consultation', { consultation_id: result.consultation_id });
            }

            showConsultationView(currentConsultation);
        }
    } catch (e) {
        showToast('Failed to start consultation: ' + e.message, 'error');
    }
}

async function declinePatient() {
    toggleNotificationPanel();
    document.getElementById('notif-badge').classList.add('hidden');
    try {
        await apiCall('/doctors/notifications/clear', 'POST');
    } catch (e) {}
    showToast('Patient request declined', 'info');
}

// ═══ VIEW MANAGEMENT ═══
function showConsultationView(consultation) {
    document.getElementById('view-waiting').classList.add('hidden');
    document.getElementById('view-consultation').classList.remove('hidden');
    document.getElementById('view-history').classList.add('hidden');

    if (consultation) {
        document.getElementById('patient-name-header').textContent = consultation.patient_name || 'Patient';
        const info = [];
        if (consultation.age) info.push(`Age: ${consultation.age}`);
        if (consultation.gender) info.push(consultation.gender);
        if (consultation.blood_group) info.push(`Blood: ${consultation.blood_group}`);
        document.getElementById('patient-info-header').textContent = info.join(' | ');

        // Load existing transcript if any
        if (consultation.transcript) {
            const lines = consultation.transcript.split('\n');
            lines.forEach(line => {
                const match = line.match(/^\[(\w+)\]:\s*(.+)$/);
                if (match) {
                    addDoctorTranscriptMessage(match[1].toLowerCase(), match[2], null, null);
                }
            });
        }
    }
}

function showWaitingView() {
    document.getElementById('view-waiting').classList.remove('hidden');
    document.getElementById('view-consultation').classList.add('hidden');
    document.getElementById('view-history').classList.add('hidden');
}

// ═══ AVAILABILITY ═══
async function toggleAvailability(available) {
    try {
        await apiCall('/doctors/availability', 'POST', { available });
        document.getElementById('stat-status').textContent = available ? 'Available' : 'Unavailable';
        document.getElementById('stat-status').style.color = available ? 'var(--success)' : 'var(--danger)';
        showToast(`Status: ${available ? 'Available' : 'Unavailable'}`, available ? 'success' : 'warning');
    } catch (e) {
        console.warn('Could not update availability:', e);
    }
}

// ═══ TRANSCRIPT ═══
function addDoctorTranscriptMessage(speaker, text, originalText, timestamp) {
    const container = document.getElementById('doc-transcript-container');
    const empty = document.getElementById('doc-transcript-empty');
    if (empty) empty.remove();

    const isPatient = speaker === 'patient';
    const avatarClass = isPatient ? 'patient-avatar' : 'doctor-avatar';
    const bubbleClass = isPatient ? 'patient-msg' : 'doctor-msg';
    const label = isPatient ? (currentConsultation?.patient_name || 'Patient') : 'You';
    const icon = isPatient ? '👤' : '🩺';

    const msgDiv = document.createElement('div');
    msgDiv.className = `transcript-message ${speaker}`;
    msgDiv.innerHTML = `
        <div class="msg-avatar ${avatarClass}">${icon}</div>
        <div>
            <div class="msg-bubble ${bubbleClass}">
                ${escapeHtml(text)}
            </div>
            ${originalText && originalText !== text ? `<div class="msg-original">Original: ${escapeHtml(originalText)}</div>` : ''}
            <div class="msg-meta">
                <span>${label}</span>
                <span>${timestamp || getNowTimestamp()}</span>
            </div>
        </div>
    `;

    container.appendChild(msgDiv);
    container.scrollTop = container.scrollHeight;

    // Update subtitle
    document.getElementById('doc-subtitle-text').textContent = text;
}

// ═══ DOCTOR VOICE ═══
function toggleDoctorRecording() {
    if (!voiceEngine) {
        const lang = document.getElementById('doc-language-select').value;
        voiceEngine = new VoiceEngine({
            language: lang,
            onTranscript: handleDoctorTranscript,
            onInterim: (text) => {
                document.getElementById('doc-subtitle-text').textContent = text;
            },
            onStatusChange: handleDoctorVoiceStatus,
            onError: (err) => showToast(err, 'error')
        });
    }

    if (voiceEngine.isRecording) {
        voiceEngine.stop();
        document.getElementById('doc-mic-btn').classList.remove('recording');
        document.getElementById('doc-mic-icon').className = 'fas fa-microphone';
        document.getElementById('doc-mic-status').className = 'mic-status';
        document.getElementById('doc-mic-status').textContent = 'Click to respond to patient';
        document.getElementById('doc-waveform').classList.add('hidden');
        document.getElementById('doc-subtitle-dot').classList.add('hidden');
    } else {
        voiceEngine.start();
        document.getElementById('doc-mic-btn').classList.add('recording');
        document.getElementById('doc-mic-icon').className = 'fas fa-stop';
        document.getElementById('doc-mic-status').className = 'mic-status recording';
        document.getElementById('doc-mic-status').textContent = '🔴 Recording...';
        document.getElementById('doc-waveform').classList.remove('hidden');
        document.getElementById('doc-subtitle-dot').classList.remove('hidden');
    }
}

function changeDoctorLanguage(lang) {
    if (voiceEngine) voiceEngine.setLanguage(lang);
}

function handleDoctorTranscript(data) {
    addDoctorTranscriptMessage('doctor', data.translated, data.original, data.timestamp);

    if (socket && currentConsultation) {
        socket.emit('send_message', {
            consultation_id: currentConsultation.id,
            speaker: 'doctor',
            text: data.translated,
            original_text: data.original,
            language: data.language,
            timestamp: data.timestamp
        });
    }
}

function handleDoctorVoiceStatus(status) {
    if (status === 'stopped') {
        document.getElementById('doc-subtitle-text').textContent = 'Microphone stopped';
    }
}

// ═══ URGENCY ═══
function showDoctorUrgencyAlert(urgency) {
    const alert = document.getElementById('doc-urgency-alert');
    const severity = urgency.severity || 'medium';
    alert.className = `urgency-alert ${severity} active`;
    document.getElementById('doc-urgency-icon').textContent = severity === 'critical' ? '🚨' : '⚠️';
    document.getElementById('doc-urgency-message').textContent = urgency.alert_message || urgency.message ||
        `Urgent keywords detected: ${(urgency.keywords || urgency.keywords_found || []).join(', ')}`;

    // Play alert sound
    if (severity === 'critical') {
        try {
            const audioCtx = new AudioContext();
            const osc = audioCtx.createOscillator();
            osc.type = 'sine';
            osc.frequency.value = 800;
            osc.connect(audioCtx.destination);
            osc.start();
            setTimeout(() => osc.stop(), 500);
        } catch (e) {}
    }
}

// ═══ AI ANALYSIS ═══
async function analyzeCurrentTranscript() {
    if (!currentConsultation) {
        showToast('No active consultation', 'warning');
        return;
    }

    const panel = document.getElementById('doc-ai-analysis');
    panel.innerHTML = '<div class="text-center"><span class="spinner"></span><p class="text-sm text-muted mt-sm">Analyzing transcript...</p></div>';

    try {
        // Get full transcript
        const consultation = await apiCall(`/consult/${currentConsultation.id}`);
        if (!consultation || !consultation.transcript) {
            panel.innerHTML = '<p class="text-muted text-sm">No transcript data available for analysis.</p>';
            return;
        }

        // Analyze symptoms
        const analysis = await apiCall('/analyse/symptoms', 'POST', { transcript: consultation.transcript });

        let html = '';

        if (analysis.symptoms && analysis.symptoms.length > 0) {
            html += `<div class="report-section">
                <h4>Symptoms</h4>
                <p>${analysis.symptoms.map(s => `<span class="badge badge-info" style="margin: 2px;">${s}</span>`).join(' ')}</p>
            </div>`;
        }

        if (analysis.diagnosis) {
            html += `<div class="report-section">
                <h4>Probable Diagnosis</h4>
                <p style="font-weight: 600; color: var(--text-primary);">${escapeHtml(analysis.diagnosis)}</p>
            </div>`;
        }

        if (analysis.cause) {
            html += `<div class="report-section">
                <h4>Probable Cause</h4>
                <p>${escapeHtml(analysis.cause)}</p>
            </div>`;
        }

        if (analysis.precautions && analysis.precautions.length > 0) {
            html += `<div class="report-section">
                <h4>Precautions</h4>
                <ul style="list-style: disc; margin-left: 1.25rem; color: var(--text-secondary); font-size: 0.85rem;">
                    ${analysis.precautions.map(p => `<li>${escapeHtml(p)}</li>`).join('')}
                </ul>
            </div>`;
        }

        const confidence = Math.round((analysis.confidence || 0) * 100);
        html += `<div class="flex items-center justify-between mt-md" style="padding-top: 0.75rem; border-top: 1px solid var(--border-color);">
            <span class="text-xs text-muted">AI Confidence</span>
            <span class="badge ${confidence >= 60 ? 'badge-success' : confidence >= 30 ? 'badge-warning' : 'badge-danger'}">${confidence}%</span>
        </div>`;

        panel.innerHTML = html;

        // Load prescription suggestions
        if (analysis.diagnosis) {
            loadPrescriptionSuggestions(analysis.diagnosis);
            // Pre-fill diet suggestions
            loadDietSuggestions(analysis.diagnosis);
        }

    } catch (e) {
        panel.innerHTML = `<p class="text-danger text-sm">Analysis failed: ${e.message}</p>`;
    }
}

async function loadPrescriptionSuggestions(diagnosis) {
    try {
        const result = await apiCall('/prescription/suggest', 'POST', { diagnosis });
        if (result && result.suggestions && result.suggestions.length > 0) {
            const container = document.getElementById('ai-suggestions');
            const list = document.getElementById('ai-suggestion-list');

            container.classList.remove('hidden');
            list.innerHTML = result.suggestions.map(s => `
                <div class="flex items-center justify-between" style="padding: 0.5rem 0; border-bottom: 1px solid var(--border-color);">
                    <div>
                        <span style="font-weight: 600; font-size: 0.85rem;">${escapeHtml(s.name)}</span>
                        <span class="text-xs text-muted"> — ${escapeHtml(s.dosage)} | ${escapeHtml(s.frequency)}</span>
                    </div>
                    <button class="btn btn-ghost btn-sm" onclick="applyAISuggestion('${escapeHtml(s.name)}', '${escapeHtml(s.dosage)}', '${escapeHtml(s.frequency)}', '${escapeHtml(s.duration || '')}')">
                        <i class="fas fa-plus"></i> Add
                    </button>
                </div>
            `).join('');
        }
    } catch (e) {}
}

async function loadDietSuggestions(diagnosis) {
    try {
        // Use API to get diet
        const transcript = `Diagnosis: ${diagnosis}`;
        const analysis = await apiCall('/analyse/symptoms', 'POST', { transcript });

        // The report generation will handle diet, but we can suggest here
        const dietInput = document.getElementById('diet-input');
        const exerciseInput = document.getElementById('exercise-input');

        if (!dietInput.value) {
            dietInput.value = 'Balanced diet with fruits and vegetables. Stay hydrated (2-3 liters water/day). Avoid processed and junk food.';
        }
        if (!exerciseInput.value) {
            exerciseInput.value = 'Regular walking (30 minutes/day). Light stretching exercises. Adequate sleep (7-8 hours).';
        }
    } catch (e) {}
}

function applyAISuggestion(name, dosage, frequency, duration) {
    addMedicineRow(name, dosage, frequency, duration);
    showToast(`Added ${name} to prescription`, 'success');
}

// ═══ PRESCRIPTION EDITOR ═══
function addMedicineRow(name = '', dosage = '', frequency = '', duration = '') {
    medicineRowCount++;
    const container = document.getElementById('medicines-container');
    const row = document.createElement('div');
    row.className = 'medicine-row';
    row.id = `med-row-${medicineRowCount}`;
    row.innerHTML = `
        <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label">Medicine Name</label>
            <input type="text" class="form-input med-name" placeholder="e.g. Paracetamol" value="${escapeHtml(name)}"
                   onblur="verifyMedicine(this, ${medicineRowCount})">
            <span class="medicine-verify-badge" id="verify-badge-${medicineRowCount}"></span>
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label">Dosage</label>
            <input type="text" class="form-input med-dosage" placeholder="e.g. 500mg" value="${escapeHtml(dosage)}">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label">Frequency</label>
            <input type="text" class="form-input med-frequency" placeholder="e.g. Twice daily" value="${escapeHtml(frequency)}">
        </div>
        <div class="form-group" style="margin-bottom: 0;">
            <label class="form-label">Duration</label>
            <input type="text" class="form-input med-duration" placeholder="e.g. 5 days" value="${escapeHtml(duration)}">
        </div>
        <button class="btn btn-danger btn-icon btn-sm" onclick="removeMedicineRow(${medicineRowCount})" title="Remove" style="align-self: end; margin-bottom: 4px;">
            <i class="fas fa-trash"></i>
        </button>
    `;
    container.appendChild(row);
}

function removeMedicineRow(id) {
    const row = document.getElementById(`med-row-${id}`);
    if (row) row.remove();
}

async function verifyMedicine(input, rowId) {
    const name = input.value.trim();
    if (!name) return;

    const badge = document.getElementById(`verify-badge-${rowId}`);
    badge.textContent = 'Verifying...';
    badge.className = 'medicine-verify-badge';

    try {
        const result = await apiCall('/prescription/verify', 'POST', { name });
        if (result && result.valid) {
            badge.textContent = `✓ Verified — ${result.category}`;
            badge.className = 'medicine-verify-badge verified';

            // Auto-fill suggested dosage if empty
            const row = document.getElementById(`med-row-${rowId}`);
            const dosageInput = row.querySelector('.med-dosage');
            const freqInput = row.querySelector('.med-frequency');
            if (!dosageInput.value && result.suggested_dosage) {
                dosageInput.value = result.suggested_dosage;
            }
            if (!freqInput.value && result.frequency) {
                freqInput.value = result.frequency;
            }

            // Show warnings
            if (result.warnings && result.warnings.length > 0) {
                showToast(`⚠️ ${name}: ${result.warnings[0]}`, 'warning', 5000);
            }
        } else {
            badge.textContent = '⚠ Not in database — verify manually';
            badge.className = 'medicine-verify-badge unverified';
        }
    } catch (e) {
        badge.textContent = '? Verification unavailable';
        badge.className = 'medicine-verify-badge unverified';
    }
}

function collectMedicines() {
    const rows = document.querySelectorAll('.medicine-row');
    const medicines = [];
    rows.forEach(row => {
        const name = row.querySelector('.med-name')?.value.trim();
        if (name) {
            medicines.push({
                name,
                dosage: row.querySelector('.med-dosage')?.value.trim() || '',
                frequency: row.querySelector('.med-frequency')?.value.trim() || '',
                duration: row.querySelector('.med-duration')?.value.trim() || ''
            });
        }
    });
    return medicines;
}

async function savePrescription() {
    if (!currentConsultation) {
        showToast('No active consultation', 'warning');
        return;
    }

    const medicines = collectMedicines();
    const diet = document.getElementById('diet-input').value.trim();
    const exercise = document.getElementById('exercise-input').value.trim();
    const notes = document.getElementById('notes-input').value.trim();

    if (medicines.length === 0) {
        showToast('Please add at least one medicine', 'warning');
        return;
    }

    try {
        const result = await apiCall('/prescription/create', 'POST', {
            consultation_id: currentConsultation.id,
            medicines,
            diet,
            exercise,
            notes
        });

        if (result && result.success) {
            showToast('Prescription saved as draft', 'success');
        }
    } catch (e) {
        showToast('Failed to save: ' + e.message, 'error');
    }
}

async function approvePrescription() {
    if (!currentConsultation) {
        showToast('No active consultation', 'warning');
        return;
    }

    // Save first
    await savePrescription();

    try {
        // Get prescription ID
        const prescription = await apiCall(`/prescription/${currentConsultation.id}`);
        if (prescription && prescription.id) {
            const result = await apiCall(`/prescription/approve/${prescription.id}`, 'POST');
            if (result && result.success) {
                showToast('✅ Prescription approved and sent to patient!', 'success');
            }
        }
    } catch (e) {
        showToast('Approval failed: ' + e.message, 'error');
    }
}

// ═══ REPORT GENERATION ═══
async function generateReport() {
    if (!currentConsultation) {
        showToast('No active consultation', 'warning');
        return;
    }

    showToast('Generating report...', 'info');

    try {
        const result = await apiCall('/report/generate', 'POST', {
            consultation_id: currentConsultation.id
        });

        if (result && result.success) {
            showToast('Report generated! Opening...', 'success');
            window.open(`/report/${currentConsultation.id}`, '_blank');
        }
    } catch (e) {
        showToast('Report generation failed: ' + e.message, 'error');
    }
}

// ═══ END CONSULTATION ═══
async function endConsultation() {
    if (!currentConsultation) return;
    if (!confirm('Are you sure you want to end this consultation?')) return;

    if (voiceEngine && voiceEngine.isRecording) {
        voiceEngine.stop();
    }

    try {
        await apiCall(`/consult/${currentConsultation.id}/complete`, 'POST');
    } catch (e) {}

    if (socket) {
        socket.emit('leave_consultation', { consultation_id: currentConsultation.id });
    }

    currentConsultation = null;
    showToast('Consultation ended', 'info');
    showWaitingView();
    loadDoctorStats();
}

// ═══ STATS ═══
async function loadDoctorStats() {
    try {
        const result = await apiCall('/history/doctor');
        if (result && result.consultations) {
            document.getElementById('stat-total').textContent = result.consultations.length;
            const today = new Date().toDateString();
            const todayCount = result.consultations.filter(c =>
                new Date(c.created_at).toDateString() === today
            ).length;
            document.getElementById('stat-today').textContent = todayCount;
        }
    } catch (e) {}
}

// ═══ HISTORY ═══
async function loadDoctorHistory() {
    document.getElementById('view-waiting').classList.add('hidden');
    document.getElementById('view-history').classList.remove('hidden');

    const list = document.getElementById('doc-history-list');
    list.innerHTML = '<div class="text-center"><span class="spinner"></span></div>';

    try {
        const result = await apiCall('/history/doctor');
        if (!result || !result.consultations || result.consultations.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><p>No past consultations</p></div>';
            return;
        }

        list.innerHTML = result.consultations.map(c => `
            <div class="history-item" onclick="this.classList.toggle('open')">
                <div class="history-header">
                    <div class="history-header-left">
                        <span class="badge ${c.urgency_level === 'critical' ? 'badge-danger' : c.urgency_level === 'high' ? 'badge-warning' : 'badge-info'}">${c.urgency_level || 'low'}</span>
                        <div>
                            <div style="font-weight: 600; font-size: 0.9rem;">${escapeHtml(c.patient_name)}</div>
                            <div class="text-xs text-muted">${c.age ? `Age ${c.age}` : ''} ${c.gender || ''} — ${formatDate(c.created_at)}</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-sm">
                        <span class="badge ${c.status === 'completed' ? 'badge-success' : 'badge-neutral'}">${c.status}</span>
                        <span class="history-chevron"><i class="fas fa-chevron-down"></i></span>
                    </div>
                </div>
                <div class="history-body">
                    <p class="text-sm"><strong>Diagnosis:</strong> ${escapeHtml(c.disease || 'N/A')}</p>
                    <button class="btn btn-primary btn-sm mt-md" onclick="event.stopPropagation(); window.open('/report/${c.id}', '_blank');">
                        <i class="fas fa-file-medical"></i> View Report
                    </button>
                </div>
            </div>
        `).join('');
    } catch (e) {
        list.innerHTML = '<div class="empty-state"><p>Could not load history</p></div>';
    }
}

// ═══ LOGOUT ═══
function handleLogout() {
    clearAuth();
    if (socket) socket.disconnect();
    if (notifPollTimer) clearInterval(notifPollTimer);
    window.location.href = '/';
}
