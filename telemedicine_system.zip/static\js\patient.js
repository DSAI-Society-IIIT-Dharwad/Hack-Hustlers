/**
 * ═══════════════════════════════════════════════════════════════
 * Patient Dashboard — Main Logic
 * Doctor selection, consultation, voice, prescriptions, history
 * ═══════════════════════════════════════════════════════════════
 */

let socket = null;
let voiceEngine = null;
let currentConsultation = null;
let currentDoctor = null;
let transcriptMessages = [];
let auth = null;

document.addEventListener('DOMContentLoaded', () => {
    auth = requireAuth('patient');
    if (!auth) return;

    document.getElementById('user-name').textContent = auth.user.name;
    VoiceEngine.populateLanguageSelector(document.getElementById('language-select'));

    // Connect WebSocket
    initSocket();

    // Load doctors
    loadDoctors();
});

// ═══ SOCKET ═══
function initSocket() {
    try {
        socket = io(API_BASE, { transports: ['websocket', 'polling'] });

        socket.on('connect', () => {
            console.log('✅ WebSocket connected');
            socket.emit('join_lobby');
        });

        socket.on('doctor_availability_changed', (data) => {
            loadDoctors(); // refresh doctor list
        });

        socket.on('new_message', (data) => {
            if (data.speaker === 'doctor') {
                addTranscriptMessage('doctor', data.text, data.original_text, data.timestamp);
                // Speak the doctor's message in English
                if (voiceEngine) voiceEngine.speak(data.text);
            }
            // Check urgency
            if (data.urgency && data.urgency.is_urgent) {
                showUrgencyAlert(data.urgency);
            }
        });

        socket.on('user_typing', (data) => {
            if (data.speaker === 'doctor') {
                document.getElementById('typing-indicator').classList.remove('hidden');
            }
        });

        socket.on('user_stopped_typing', (data) => {
            document.getElementById('typing-indicator').classList.add('hidden');
        });

        socket.on('prescription_approved', (data) => {
            showToast('Doctor approved your prescription!', 'success');
            loadPrescription(data.consultation_id);
        });

        socket.on('consultation_ended', (data) => {
            showToast('Consultation has ended.', 'info');
            loadPrescription(currentConsultation?.id);
        });

        socket.on('disconnect', () => {
            console.log('❌ WebSocket disconnected');
        });
    } catch (e) {
        console.warn('WebSocket not available:', e);
    }
}

// ═══ DOCTOR SELECTION ═══
// Store doctor data for click handling
let doctorsData = [];

async function loadDoctors() {
    const grid = document.getElementById('doctor-grid');

    try {
        const result = await apiCall('/doctors/list');
        if (!result || !result.doctors) {
            renderOfflineDoctors(grid);
            return;
        }

        doctorsData = result.doctors;
        if (doctorsData.length === 0) {
            grid.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🩺</div><p>No doctors registered yet</p></div>';
            return;
        }

        renderDoctorCards(grid, doctorsData);

    } catch (e) {
        console.error('Failed to load doctors:', e);
        renderOfflineDoctors(grid);
    }
}

function renderDoctorCards(grid, doctors) {
    grid.innerHTML = doctors.map(doc => `
        <div class="doctor-card ${doc.available ? '' : 'unavailable'}"
             data-doctor-id="${doc.doctor_id}"
             data-doctor-name="${doc.name.replace(/"/g, '&quot;')}"
             data-doctor-spec="${(doc.specialization || '').replace(/"/g, '&quot;')}"
             data-available="${doc.available ? '1' : '0'}"
             id="doctor-card-${doc.doctor_id}">
            <div class="doctor-status">
                ${doc.available
                    ? '<span class="badge badge-success"><span class="badge-dot badge-dot-success"></span> Available</span>'
                    : '<span class="badge badge-neutral"><span class="badge-dot badge-dot-danger"></span> Unavailable</span>'
                }
            </div>
            <div class="doctor-avatar">${getInitials(doc.name)}</div>
            <div class="doctor-name">${escapeHtml(doc.name)}</div>
            <div class="doctor-spec">${escapeHtml(doc.specialization || '')}</div>
            <div class="doctor-exp">${doc.experience_years} years experience</div>
        </div>
    `).join('');

    // Attach click handlers via delegation
    grid.querySelectorAll('.doctor-card').forEach(card => {
        card.addEventListener('click', function() {
            const available = this.dataset.available === '1';
            if (!available) {
                showToast('Doctor is currently unavailable', 'warning');
                return;
            }
            const id = parseInt(this.dataset.doctorId);
            const name = this.dataset.doctorName;
            const spec = this.dataset.doctorSpec;
            selectDoctor(id, name, spec);
        });
    });
}

function renderOfflineDoctors(grid) {
    const offlineDoctors = [
        { doctor_id: 1, name: 'Dr. Arun Sharma', specialization: 'Cardiology', experience_years: 15, available: 1 },
        { doctor_id: 2, name: 'Dr. Priya Patel', specialization: 'General Medicine', experience_years: 10, available: 1 },
        { doctor_id: 3, name: 'Dr. Rajesh Kumar', specialization: 'Neurology', experience_years: 12, available: 1 },
        { doctor_id: 4, name: 'Dr. Sneha Reddy', specialization: 'Pediatrics', experience_years: 8, available: 1 },
    ];
    renderDoctorCards(grid, offlineDoctors);
}

async function selectDoctor(doctorId, doctorName, specialization) {
    currentDoctor = { id: doctorId, name: doctorName, specialization };

    // Notify doctor
    try {
        await apiCall('/doctors/notify', 'POST', {
            doctor_id: doctorId,
            patient_id: auth.user.role_id || 1
        });
    } catch (e) {
        console.warn('Could not notify doctor:', e);
    }

    // Start consultation
    try {
        const result = await apiCall('/consult/start', 'POST', {
            patient_id: auth.user.role_id || 1,
            doctor_id: doctorId
        });

        if (result && result.consultation_id) {
            currentConsultation = { id: result.consultation_id, doctor_id: doctorId };

            // Join consultation room
            if (socket) {
                socket.emit('join_consultation', { consultation_id: result.consultation_id });
            }
        } else {
            // Offline mode
            currentConsultation = { id: Date.now(), doctor_id: doctorId };
        }
    } catch (e) {
        currentConsultation = { id: Date.now(), doctor_id: doctorId };
    }

    // Switch to consultation view
    showConsultationView(doctorName, specialization);
    showToast(`Connected to ${doctorName}`, 'success');
}

// ═══ VIEW MANAGEMENT ═══
function showConsultationView(doctorName, spec) {
    document.getElementById('view-doctor-select').classList.add('hidden');
    document.getElementById('view-consultation').classList.remove('hidden');
    document.getElementById('view-history').classList.add('hidden');
    document.getElementById('history-toggle').classList.add('hidden');

    document.getElementById('consult-doctor-name').textContent = doctorName;
    document.getElementById('consult-doctor-spec').textContent = spec;

    transcriptMessages = [];
}

function showDoctorSelect() {
    document.getElementById('view-doctor-select').classList.remove('hidden');
    document.getElementById('view-consultation').classList.add('hidden');
    document.getElementById('view-history').classList.add('hidden');
    document.getElementById('history-toggle').classList.remove('hidden');
}

function backToDoctorSelect() {
    if (currentConsultation) {
        if (!confirm('Leave this consultation?')) return;
    }
    stopRecording();
    currentConsultation = null;
    currentDoctor = null;
    showDoctorSelect();
    loadDoctors();
}

// ═══ VOICE RECORDING ═══
function toggleRecording() {
    if (!voiceEngine) {
        const lang = document.getElementById('language-select').value;
        voiceEngine = new VoiceEngine({
            language: lang,
            onTranscript: handleTranscript,
            onInterim: handleInterim,
            onStatusChange: handleVoiceStatus,
            onError: (err) => showToast(err, 'error')
        });
    }

    if (voiceEngine.isRecording) {
        stopRecording();
    } else {
        startRecording();
    }
}

function startRecording() {
    if (voiceEngine) {
        voiceEngine.start();
        document.getElementById('mic-btn').classList.add('recording');
        document.getElementById('mic-icon').className = 'fas fa-stop';
        document.getElementById('mic-status').className = 'mic-status recording';
        document.getElementById('mic-status').textContent = '🔴 Recording... Speak now';
        document.getElementById('waveform').classList.remove('hidden');
        document.getElementById('subtitle-dot').classList.remove('hidden');
    }
}

function stopRecording() {
    if (voiceEngine) {
        voiceEngine.stop();
        document.getElementById('mic-btn').classList.remove('recording');
        document.getElementById('mic-icon').className = 'fas fa-microphone';
        document.getElementById('mic-status').className = 'mic-status';
        document.getElementById('mic-status').textContent = 'Click microphone to start speaking';
        document.getElementById('waveform').classList.add('hidden');
        document.getElementById('subtitle-dot').classList.add('hidden');
    }
}

function changeLanguage(lang) {
    if (voiceEngine) {
        voiceEngine.setLanguage(lang);
    }
}

function handleTranscript(data) {
    // Add to transcript
    addTranscriptMessage('patient', data.translated, data.original, data.timestamp);

    // Send via WebSocket
    if (socket && currentConsultation) {
        socket.emit('send_message', {
            consultation_id: currentConsultation.id,
            speaker: 'patient',
            text: data.translated,
            original_text: data.original,
            language: data.language,
            timestamp: data.timestamp
        });
    }

    // Update subtitle
    document.getElementById('subtitle-text').textContent = data.translated;

    // Speak translation in English (if source wasn't English)
    if (data.language !== 'en' && voiceEngine) {
        voiceEngine.speak(data.translated);
    }

    // Update AI analysis locally
    updateAIAnalysis(data.translated);
}

function handleInterim(text) {
    document.getElementById('subtitle-text').textContent = text;
}

function handleVoiceStatus(status) {
    if (status === 'stopped') {
        document.getElementById('subtitle-text').textContent = 'Microphone stopped';
    }
}

// ═══ TRANSCRIPT ═══
function addTranscriptMessage(speaker, text, originalText, timestamp) {
    const container = document.getElementById('transcript-container');
    const empty = document.getElementById('transcript-empty');
    if (empty) empty.remove();

    transcriptMessages.push({ speaker, text, originalText, timestamp });

    const isPatient = speaker === 'patient';
    const avatarClass = isPatient ? 'patient-avatar' : 'doctor-avatar';
    const bubbleClass = isPatient ? 'patient-msg' : 'doctor-msg';
    const label = isPatient ? 'You' : (currentDoctor?.name || 'Doctor');
    const icon = isPatient ? '👤' : '🩺';

    const msgDiv = document.createElement('div');
    msgDiv.className = `transcript-message ${speaker}`;
    msgDiv.innerHTML = `
        <div class="msg-avatar ${avatarClass}">${icon}</div>
        <div>
            <div class="msg-bubble ${bubbleClass}">
                ${escapeHtml(text)}
            </div>
            ${originalText && originalText !== text ? `<div class="msg-original">Original: ${escapeHtml(originalText)}</div>` : ''}
            <div class="msg-meta">
                <span>${label}</span>
                <span>${timestamp || getNowTimestamp()}</span>
            </div>
        </div>
    `;

    container.appendChild(msgDiv);
    container.scrollTop = container.scrollHeight;
}

// ═══ AI ANALYSIS (Local / Live) ═══
let allTranscriptText = '';

function updateAIAnalysis(newText) {
    allTranscriptText += ' ' + newText;

    const panel = document.getElementById('ai-analysis-content');

    // Simple local urgency check
    const urgentKeywords = ['chest pain', 'breathing difficulty', 'unconscious', 'severe bleeding', 'heart attack',
                            'seizure', 'choking', 'stroke', 'not breathing'];
    const mediumKeywords = ['fever', 'cough', 'headache', 'vomiting', 'diarrhea', 'pain', 'nausea', 'dizziness'];

    const textLower = allTranscriptText.toLowerCase();
    const foundUrgent = urgentKeywords.filter(k => textLower.includes(k));
    const foundMedium = mediumKeywords.filter(k => textLower.includes(k));

    let html = '';

    if (foundUrgent.length > 0) {
        html += `<div class="urgency-alert critical active" style="display: flex;">
            <span class="urgency-icon">🚨</span>
            <span>Critical symptoms detected: ${foundUrgent.join(', ')}</span>
        </div>`;
    }

    if (foundMedium.length > 0 || foundUrgent.length > 0) {
        html += `<div class="report-section">
            <h4>Symptoms Detected</h4>
            <p>${[...foundUrgent, ...foundMedium].map(s => `<span class="badge ${foundUrgent.includes(s) ? 'badge-danger' : 'badge-info'}" style="margin: 2px;">${s}</span>`).join(' ')}</p>
        </div>`;
    }

    if (foundMedium.length === 0 && foundUrgent.length === 0) {
        html = `<div class="empty-state" style="padding: 1.5rem;">
            <div class="empty-state-icon">🤖</div>
            <p class="text-sm">Continue describing your symptoms for AI analysis.</p>
        </div>`;
    }

    panel.innerHTML = html;
}

function showUrgencyAlert(urgency) {
    const alert = document.getElementById('urgency-alert');
    alert.className = `urgency-alert ${urgency.severity} active`;
    document.getElementById('urgency-icon').textContent = urgency.severity === 'critical' ? '🚨' : '⚠️';
    document.getElementById('urgency-message').textContent = urgency.alert_message;
}

// ═══ PRESCRIPTION ═══
async function loadPrescription(consultationId) {
    if (!consultationId) return;

    try {
        const prescription = await apiCall(`/prescription/${consultationId}`);
        if (prescription && prescription.approved) {
            displayPrescription(prescription);
        }
    } catch (e) {
        console.warn('Could not load prescription:', e);
    }
}

function displayPrescription(prescription) {
    const panel = document.getElementById('prescription-panel');
    panel.style.display = 'block';

    const content = document.getElementById('prescription-content');
    let html = '';

    if (prescription.medicines && prescription.medicines.length > 0) {
        html += '<table class="report-table"><thead><tr><th>Medicine</th><th>Dosage</th><th>Frequency</th><th>Duration</th></tr></thead><tbody>';
        prescription.medicines.forEach(m => {
            html += `<tr><td style="font-weight:600;">${escapeHtml(m.name)}</td><td>${escapeHtml(m.dosage)}</td><td>${escapeHtml(m.frequency)}</td><td>${escapeHtml(m.duration || '—')}</td></tr>`;
        });
        html += '</tbody></table>';
    }

    if (prescription.diet) {
        html += `<div class="report-section mt-md"><h4>🥗 Diet</h4><p>${escapeHtml(prescription.diet)}</p></div>`;
    }
    if (prescription.exercise) {
        html += `<div class="report-section"><h4>🏃 Exercise</h4><p>${escapeHtml(prescription.exercise)}</p></div>`;
    }

    content.innerHTML = html;
    showToast('Prescription received!', 'success');
}

function viewReport() {
    if (currentConsultation) {
        window.open(`/report/${currentConsultation.id}`, '_blank');
    }
}

// ═══ HISTORY ═══
async function loadHistory() {
    document.getElementById('view-doctor-select').classList.add('hidden');
    document.getElementById('view-history').classList.remove('hidden');
    document.getElementById('history-toggle').classList.add('hidden');

    const list = document.getElementById('history-list');
    list.innerHTML = '<div class="text-center"><span class="spinner"></span></div>';

    try {
        const result = await apiCall(`/history/patient/${auth.user.role_id || 1}`);
        if (!result || !result.consultations || result.consultations.length === 0) {
            list.innerHTML = '<div class="empty-state"><div class="empty-state-icon">📋</div><p>No past consultations found</p></div>';
            return;
        }

        list.innerHTML = result.consultations.map(c => `
            <div class="history-item" onclick="this.classList.toggle('open')">
                <div class="history-header">
                    <div class="history-header-left">
                        <span class="badge ${c.urgency_level === 'critical' ? 'badge-danger' : c.urgency_level === 'high' ? 'badge-warning' : 'badge-info'}">${c.urgency_level || 'low'}</span>
                        <div>
                            <div style="font-weight: 600; font-size: 0.9rem;">${escapeHtml(c.doctor_name)}</div>
                            <div class="text-xs text-muted">${c.specialization} — ${formatDate(c.created_at)}</div>
                        </div>
                    </div>
                    <div class="flex items-center gap-sm">
                        <span class="badge ${c.status === 'completed' ? 'badge-success' : 'badge-neutral'}">${c.status}</span>
                        <span class="history-chevron"><i class="fas fa-chevron-down"></i></span>
                    </div>
                </div>
                <div class="history-body">
                    <p class="text-sm"><strong>Problem:</strong> ${escapeHtml(c.problem || 'N/A')}</p>
                    <p class="text-sm mt-sm"><strong>Diagnosis:</strong> ${escapeHtml(c.disease || 'N/A')}</p>
                    <button class="btn btn-primary btn-sm mt-md" onclick="event.stopPropagation(); window.open('/report/${c.id}', '_blank');">
                        <i class="fas fa-file-medical"></i> View Report
                    </button>
                </div>
            </div>
        `).join('');
    } catch (e) {
        list.innerHTML = '<div class="empty-state"><p>Could not load history</p></div>';
    }
}

// ═══ CONSULTATION END ═══
async function endConsultation() {
    if (!currentConsultation) return;
    if (!confirm('Are you sure you want to end this consultation?')) return;

    stopRecording();

    try {
        await apiCall(`/consult/${currentConsultation.id}/complete`, 'POST');
    } catch (e) {
        console.warn('Could not end consultation on server:', e);
    }

    if (socket) {
        socket.emit('leave_consultation', { consultation_id: currentConsultation.id });
    }

    showToast('Consultation ended', 'info');
    loadPrescription(currentConsultation.id);
}

// ═══ LOGOUT ═══
function handleLogout() {
    clearAuth();
    if (socket) socket.disconnect();
    window.location.href = '/';
}
